package dao;

public interface ICounterDAO {
    void saveCounter(int counterValue);
}
