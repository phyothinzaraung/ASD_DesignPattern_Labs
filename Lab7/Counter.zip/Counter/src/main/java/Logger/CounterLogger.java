package Logger;

public class CounterLogger {

    public void log(int counterValue){
        System.out.println("Saving to Log: " + counterValue);
    }
}
