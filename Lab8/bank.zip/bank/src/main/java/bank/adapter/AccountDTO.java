package bank.adapter;

public class AccountDTO {

    long accountnumber;

    public long getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(long accountnumber) {
        this.accountnumber = accountnumber;
    }
}
