package order;

public interface IPaymentType {
}
