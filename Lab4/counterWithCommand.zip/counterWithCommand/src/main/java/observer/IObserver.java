package observer;

public interface IObserver {
    public void update(int count);
}
