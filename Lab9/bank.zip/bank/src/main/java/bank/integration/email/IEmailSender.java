package bank.integration.email;

public interface IEmailSender {
    public void sendEmail();
}
